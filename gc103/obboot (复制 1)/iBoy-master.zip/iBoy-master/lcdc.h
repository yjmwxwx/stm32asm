
#ifndef __LCDC_H__
#define __LCDC_H__

void stat_trigger();
void stat_change(int stat);
void lcdc_change(unsigned char b);
void lcdc_trans();

#endif




