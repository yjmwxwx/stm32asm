

#ifndef __SAVE_H__
#define __SAVE_H__

void loadstate(FILE *f);
void savestate(FILE *f);

#endif

















