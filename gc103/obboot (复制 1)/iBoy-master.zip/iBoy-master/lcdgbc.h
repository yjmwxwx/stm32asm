#ifndef __LCDGBC_H__
#define __LCDGBC_H__

#include "defs.h"

void updatepalette(int i, int scanline);

#endif
