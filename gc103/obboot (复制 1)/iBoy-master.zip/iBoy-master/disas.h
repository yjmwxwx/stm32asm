#ifndef DISAS_H_
#define DISAS_H_

void debug_disassemble(addr a, int c);
void disasm_all();

#endif /*DISAS_H_*/
