
#define cpu _cpu
#define hw _hw
#define ram _ram
#define mbc _mbc
#define lcd _lcd
#define scan _scan
#define patpix _patpix
#define anydirty _anydirty
#define patdirty _patdirty
#define cpu_emulate _cpu_emulate
#define cpu_step _cpu_step
#define lcdc_trans _lcdc_trans
#define debug_trace _debug_trace
#define updatepatpix _updatepatpix
#define debug_disassemble _debug_disassemble
#define bg_scan_color _bg_scan_color

#define mem_read _mem_read
#define mem_write _mem_write
#define cpu_idle _cpu_idle
#define die _die
#define printf _printf
