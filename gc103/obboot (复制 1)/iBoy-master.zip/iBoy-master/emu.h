
#ifndef __EMU_H__
#define __EMU_H__

void emu_init();
void emu_reset();
void emu_run();
void emu_reload();

#endif








