/* not worth copyrighting */
#include "bench.h"

/* default routine, can be overridden by user */
void bench_exit(int status)
{
     exit(status);
}
