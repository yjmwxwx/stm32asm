#pragma once

void
panic(const char *fmt, ...);
